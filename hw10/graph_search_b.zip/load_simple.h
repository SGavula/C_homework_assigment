#ifndef __LOAD_SIMPLE_H__
#define __LOAD_SIMPLE_H__

#define INIT_SIZE 10
#define ERR_FILE 100

#include "graph.h"

int load_graph_simple(const char *fname, graph_t *g);

#endif
