//Source of compare function - https://www.javatpoint.com/c-program-to-compare-the-two-strings
#include "stdio.h"
#include "stdlib.h"
#include "stdbool.h"

#define INIT_SIZE 10
#define FILE_CLOSE_ERR -1

enum {
    INPUT_ERR = 100,
    ALLOC_ERR,
    FILE_ERR,
};

int compare(char a[],char b[]);

int main(int argc, char* argv[]) {
    char c;
    char* msg = NULL;
    char* file_name = NULL;
    int length = 0;
    int *line = NULL;
    int array_size = INIT_SIZE;
    int array_size2 = INIT_SIZE;
    bool isInRow = false;
    bool isEmpty = true;
    int i = 0;
    int* value_arr = NULL;
    bool isColor = false;
    bool isStdin = false;

    if(argc < 2) {
        fprintf(stderr, "Error input\n");
        return INPUT_ERR;
    }else if(argc == 2) {
        msg = argv[1];
        isStdin = true;
    }else if(argc == 3) {
        msg = argv[1];
        file_name = argv[2];
    }else {
        for(int i = 0; i < argc; i++) {
            if(compare(argv[i], "--color=always") == 0) {
                isColor = true;
            }
        }
        msg = argv[argc-2];
        file_name = argv[argc-1];
    }

    //Length of searching word
    while(msg[length] != '\0') {
        length++;
    }

    //Declaration of file
    FILE *f;
    if(isStdin != true) {
        if((f = fopen(file_name, "r")) == NULL) {
            fprintf(stderr, "Error: Cannot open the file\n");
            return FILE_ERR;
        }
    }

    line = malloc(sizeof(int) * array_size);
    if(line == NULL) {
        fprintf(stderr, "Error: Cannot malloc!\n");
        free(line);
        line = NULL;
        exit(ALLOC_ERR);
    }

    value_arr = malloc(sizeof(int) * array_size2);
    if(value_arr == NULL) {
        fprintf(stderr, "Error: Cannot malloc!\n");
        free(value_arr);
        value_arr = NULL;
        exit(ALLOC_ERR);
    }

    int value_arr_row = 0;
    int compared_text_ind = 0;
    char compared_text[length + 1];

    while(isStdin ? (c = getchar()) != EOF : (c = getc(f)) != EOF) {
        //Save content of line in array
        line[i] = c;

        if(compared_text_ind == length) {
            compared_text[length] = '\0';
            int r = compare(compared_text, msg);
            if(r == 0) {
                isInRow = true;
                isEmpty = false;
                compared_text_ind = 0;
                compared_text[compared_text_ind] = c;
                compared_text_ind++;
                value_arr[value_arr_row] = (i - 1 - length);
                value_arr_row++;
                if(value_arr_row >= array_size2) {
                    int* tmp2 = NULL;
                    array_size2 = array_size2 * 2;
                    tmp2 = realloc(value_arr, sizeof(int) * array_size2);
                    if(tmp2 == NULL) {
                        fprintf(stderr, "Error: Cannot realloc!\n");
                        free(value_arr);
                        value_arr = NULL;
                        exit(ALLOC_ERR);
                    }
                    value_arr = tmp2;
                }
            }else {
                for(int l = 0; l < (length - 1); l++) {
                    compared_text[l] = compared_text[l+1];
                }
                compared_text_ind--;
                compared_text[compared_text_ind] = c;
                compared_text_ind++;
            }
        }else {
            compared_text[compared_text_ind] = c;
            compared_text_ind++;
        }

        i++;

        if(i >= array_size) {
            int* tmp = NULL;
            array_size = array_size * 2;
            tmp = realloc(line, sizeof(int) * array_size);
            if(tmp == NULL) {
                fprintf(stderr, "Error: Cannot realloc!\n");
                free(line);
                line = NULL;
                exit(ALLOC_ERR);
            }
            line = tmp;
        }


        if(c == '\n') {
            int row = 0;
            if(isInRow == true) {
                for(int j = 0; j < (i-1); j++) {
                    if(isColor == true) {
                        if(row < value_arr_row) {
                            if(value_arr[row] == (-1) && j == 0) {
                                printf("\x1b[01;31m\x1b[K");
                            }
                        }
                    }
                    printf("%c", line[j]);

                    if(isColor == true) {
                        if(row < value_arr_row) {
                            if(j == (value_arr[row] + length)) {
                                printf("\x1b[m\x1b[K");
                                row++;
                            }
                        }
                        if(row < value_arr_row) {
                            if(j == value_arr[row]) {
                                printf("\x1b[01;31m\x1b[K");
                            }
                        }
                    }
                }

                printf("\n");
            }
            i = 0;
            isInRow = false;
            free(line);
            free(value_arr);
            //Malloc line
            array_size = INIT_SIZE;
            // printf("Array_size: %i\n", array_size);
            line = malloc(sizeof(int) * array_size);
            if(line == NULL) {
                fprintf(stderr, "Error: Cannot malloc!\n");
                free(line);
                line = NULL;
                exit(ALLOC_ERR);
            }
            
            value_arr_row = 0;
            array_size2 = INIT_SIZE;
            value_arr = malloc(sizeof(int) * array_size2);
            if(value_arr == NULL) {
                fprintf(stderr, "Error: Cannot malloc!\n");
                free(value_arr);
                value_arr = NULL;
                exit(ALLOC_ERR);
            }
        }
    }


    if(isStdin != true) {
        if (fclose(f) == EOF) {
            fprintf(stderr, "Error: Close file ’%s’\n", file_name);
            return FILE_CLOSE_ERR;
        }
    }



    if(isInRow == true) {
        for(int j = 0; j < (i-1); j++) {
            printf("%c", line[j]);
        }
        printf("\n");
    }

    free(line);
    free(value_arr);
    
    if(isEmpty == true) {
        return 1;
    }
    
    return 0;
}

int compare(char a[],char b[]) {  
    int flag=0,i=0;  // integer variables declaration  
    while(a[i]!='\0' &&b[i]!='\0')  // while loop  
    {  
       if(a[i]!=b[i])  
       {  
           flag=1;  
           break;  
       }  
       i++;  
    }  
    if(flag==0) {
        return 0;  
    } else {
        return 1;  
    }
}
